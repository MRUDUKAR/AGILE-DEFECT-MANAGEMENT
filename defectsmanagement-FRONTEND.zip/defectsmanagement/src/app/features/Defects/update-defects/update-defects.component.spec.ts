import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDefectsComponent } from './update-defects.component';

describe('UpdateDefectsComponent', () => {
  let component: UpdateDefectsComponent;
  let fixture: ComponentFixture<UpdateDefectsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UpdateDefectsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UpdateDefectsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
