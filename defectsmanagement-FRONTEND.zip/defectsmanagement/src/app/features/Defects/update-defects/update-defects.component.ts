import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { response } from 'express';
import { Defect } from '../models/defect.model';
import { UpdateDefect } from '../models/update-defect.model';
import { DefectService } from '../services/defect.service';

@Component({
  selector: 'app-update-defects',
  templateUrl: './update-defects.component.html',
  styleUrl: './update-defects.component.css'
})
export class UpdateDefectsComponent implements OnInit{
  defectId1: number | null=null;
  defects: Defect;
  constructor(private router:Router,
    private route:ActivatedRoute,
    private service : DefectService){}

    ngOnInit(): void {
      this.route.paramMap.subscribe({
        next:(params) => {
          const Id = params.get('defectId1');
          if(Id!=null){
            this.defectId1=parseInt(Id);
          }
          if(this.defectId1){
            this.service.defectDetails(this.defectId1)
            .subscribe({
              next:(response)=>{
                this.defects = response;
              }
            });
          }
        }
      });
    }

    onSubmit() : void{
      const update : UpdateDefect={
        status1: this.defects?.status1 ?? ''
      };
      if(this.defectId1){
        this.service.updatestatus(update,this.defectId1)
        .subscribe({
          next:(response)=>{
            this.router.navigateByUrl('/Defects/DefectDetails');
            console.log(response);
          }
        });
      }
      }
}
  

