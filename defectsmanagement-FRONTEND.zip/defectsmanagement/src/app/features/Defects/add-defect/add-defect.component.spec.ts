import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDefectComponent } from './add-defect.component';

describe('AddDefectComponent', () => {
  let component: AddDefectComponent;
  let fixture: ComponentFixture<AddDefectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddDefectComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddDefectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
