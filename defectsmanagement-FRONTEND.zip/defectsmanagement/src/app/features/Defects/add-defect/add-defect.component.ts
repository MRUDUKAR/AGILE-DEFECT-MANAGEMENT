import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { response } from 'express';
import { AddDefectRequest, Priority1_Value, Severity1_Value } from '../models/add-defect-request.model';
import { DefectService } from '../services/defect.service';

@Component({
  selector: 'app-add-defect',
  templateUrl: './add-defect.component.html',
  styleUrl: './add-defect.component.css'
})
export class AddDefectComponent {

   model : AddDefectRequest;

   constructor(private router:Router,
    private route:ActivatedRoute,private defectService: DefectService){
    this.model = {
      title1: '',
    defectDetails1: '',
    stepsToReproduce1: '',
    priority1: Priority1_Value.P1,
    reportedByTesterId1: '',
    assignedToDeveloperId1: '',
    severity1: Severity1_Value.blocker,
    status1: '',
    projectCode1:null,

    };
   }

   priorities:Priority1_Value[]=[Priority1_Value.P1,Priority1_Value.P2,Priority1_Value.P3]
   severities:Severity1_Value[]=[Severity1_Value.blocker,Severity1_Value.critical,Severity1_Value.major,Severity1_Value.minor,Severity1_Value.low]


  onFormSubmit(){
    if(this.model.defectDetails1.split(" ").length < 10){
      alert("Defect details must be atleast 10 words.");
    }
    if(this.model.stepsToReproduce1.split(" ").length < 10){
      alert("Steps To Reproduce must be atleast 10 words.");
    }
    if(this.model.reportedByTesterId1.length < 6){
      alert("Tester Id must be atleast 6 characters");
    }
    if(this.model.assignedToDeveloperId1.length < 6){
      alert("Developer Id must be atleast 6 characters");
    }

     this.defectService.addDefect(this.model)
     .subscribe({
      next: (response) => {
        alert("Defect Added successfully....")
        this.router.navigateByUrl('/Defects/Home')
        console.log(response);
      }
     })
  }
}
