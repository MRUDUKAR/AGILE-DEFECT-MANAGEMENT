export enum Priority1_Value
{
    P1=1,
    P2=2,
    P3=3,
}

export enum Severity1_Value
{
    blocker=1,
    critical=2,
    major=3,
    minor=4,
    low=5,
}


export interface Defect {
    defectId1:Number;
    title1: string;
    defectDetails1: string;
    stepsToReproduce1: string;
    priority1: Priority1_Value;
    defectedOn1: Date;
    expectedResolution1: Date;
    reportedByTesterId1: string;
    assignedToDeveloperId1: string;
    severity1: Severity1_Value;
    status1: string;
    projectCode1?:Number;
}