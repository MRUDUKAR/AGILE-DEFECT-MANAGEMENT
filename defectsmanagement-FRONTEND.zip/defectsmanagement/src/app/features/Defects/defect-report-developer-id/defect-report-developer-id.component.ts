import { Component } from '@angular/core';
import { Defect } from '../models/defect.model';
import { DefectService } from '../services/defect.service';

@Component({
  selector: 'app-defect-report-developer-id',
  templateUrl: './defect-report-developer-id.component.html',
  styleUrl: './defect-report-developer-id.component.css'
})
export class DefectReportDeveloperIdComponent {

  developerId1 : string ='';
  defects: Defect[];
  a:number=0;

  constructor(private defectService:DefectService){

  }

  onSubmit(){

    if(this.developerId1.length < 6){
      alert("Developer Id must be atleast 6 characters");
    }
    console.log(this.developerId1);
    this.defectService.defectsReportByDeveloperId(this.developerId1)
    .subscribe(
      (response) => {
        console.log(response);
       this.defects= response;
       if(this.defects.length != 0){
        this.a=1;
       }
       else{
        this.a=2;
       }
       
      },
      (error) => {
        console.error('Error Fetching Defect Details:', error);
      }
    );
}

}
