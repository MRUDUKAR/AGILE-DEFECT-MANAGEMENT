﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using DefectManagement1_DAL.Models;
namespace DefectManagement_DAL.Models
{
    public class Defect1
    {
        public enum Priority1_value
        {
            P1=1,
            P2=2,
            P3=3,
        }

        public enum Severity1_value
        {
            blocker=1,
            critical=2,
            major=3,
            minor=4,
            low=5,
        }

        [Key]
        [Required]
        [Range(1,11)]
        public int DefectId1 { get; set; }

        [Required]
        [StringLength(100)]
        public string Title1 { get; set; }

     
        [StringLength(500)]
        public string DefectDetails1 { get; set; }

        [Required]
        [StringLength (1000)]
        public string StepsToReproduce1 { get; set; }

        [Required]
        [StringLength(2)]
        [EnumDataType(typeof(Priority1_value))]
        public Priority1_value Priority1 { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateOnly DefectedOn1 { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DateGreaterEqualThanCurrent(ErrorMessage ="ExpectedResolutionDate must be a future or today's date.")]
        public DateOnly ExpectedResolution1 { get; set;}

        [Required]
        [StringLength(6,ErrorMessage="Length of the testerid is less than or equal to 6 character only")]
        public string ReportedByTesterId1 { get; set; }

        [Required]
        [StringLength(6,ErrorMessage ="Length of the developerid is less than or equal to 6 characters only.")]
        public string AssignedToDeveloperId1 { get; set; }

        [Required]
        [StringLength(15)]
        [EnumDataType(typeof(Severity1_value))]
        public Severity1_value Severity1 { get; set; }

        [Required]
        [StringLength(10)]
        public string Status1 { get; set; }

        [Required]
        [Range(1,11)]
        public int ProjectCode1 { get; set; }

    }
}
