﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DefectManagement1_DAL.Migrations
{
    /// <inheritdoc />
    public partial class final1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "DefectDeatils1",
                table: "Defect1s",
                newName: "DefectDetails1");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "DefectDetails1",
                table: "Defect1s",
                newName: "DefectDeatils1");
        }
    }
}
