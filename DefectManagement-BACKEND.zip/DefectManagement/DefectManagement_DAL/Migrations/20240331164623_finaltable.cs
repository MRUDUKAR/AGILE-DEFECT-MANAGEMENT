﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DefectManagement1_DAL.Migrations
{
    /// <inheritdoc />
    public partial class finaltable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Resolutions1s");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Resolutions1s",
                columns: table => new
                {
                    ResolutionId1 = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DefectId1 = table.Column<int>(type: "int", nullable: false),
                    Resolution1 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    ResolutionDate1 = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Resolutions1s", x => x.ResolutionId1);
                    table.ForeignKey(
                        name: "FK_Resolutions1s_Defect1s_DefectId1",
                        column: x => x.DefectId1,
                        principalTable: "Defect1s",
                        principalColumn: "DefectId1",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Resolutions1s_DefectId1",
                table: "Resolutions1s",
                column: "DefectId1");
        }
    }
}
