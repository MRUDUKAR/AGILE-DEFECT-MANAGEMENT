﻿using DefectManagement_DAL.Models;
using DefectManagement1_DAL.DbContexts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefectManagement1_DAL.Repository
{
    public class DemoRepository : IDemoRepository
    {
        private readonly DemoContext _context1;

        public DemoRepository(DemoContext context1)
        {
            _context1 = context1;
        }
        public bool AddNewDemoDefect(Defect1 defect1)
        {
            try
            {
                _context1.Defect1s.Add(defect1);
                _context1.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public IList<Defect1>? GetDemoDefectAssignToDeveloper(string developer1id1)
        {
            var hell1 = _context1.Defect1s.Where(d=>d.AssignedToDeveloperId1 == developer1id1).ToList();
            return hell1;
        }

        public Defect1 GetDemoDefectById(int id)
        {
            var hell2 = _context1.Defect1s.FirstOrDefault(d => d.DefectId1 == id);
            return hell2;
        }

        public IList<Defect1> GetDemoDefectReport(int demoprojectcode)
        {
            var hell3 = _context1.Defect1s.Where(d=>d.ProjectCode1==demoprojectcode).ToList();
            return hell3;
        }

        public bool UpdateDemoDefect(Defect1 defect1,int id)
        {
            try
            {
                var existingdemodefect = _context1.Defect1s.Where(d=>d.DefectId1==id).SingleOrDefault();
                existingdemodefect.Status1 = defect1.Status1;
                _context1.Entry(existingdemodefect).State = EntityState.Modified;
                _context1.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
           
        }
    }
}
