﻿using DefectManagement_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefectManagement1_DAL.Repository
{
    public interface IDemoRepository
    {
        public bool AddNewDemoDefect(Defect1 defect1)
        {
            return false;
        }

        public Defect1? GetDemoDefectById(int id);

        public IList<Defect1>? GetDemoDefectAssignToDeveloper(string Developer1id1);

        public bool UpdateDemoDefect(Defect1 defect1,int id)
        {
            return false;
        }

        public IList<Defect1>? GetDemoDefectReport(int projectcode);
    }
}
