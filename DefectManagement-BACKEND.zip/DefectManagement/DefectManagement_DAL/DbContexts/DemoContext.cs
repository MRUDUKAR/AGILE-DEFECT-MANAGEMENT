﻿using DefectManagement_DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefectManagement1_DAL.DbContexts
{
    public class DemoContext : DbContext
    {
        public DemoContext() { }

        public DemoContext(DbContextOptions<DemoContext> options) : base(options) { }

        public DbSet<Defect1> Defect1s { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\ProjectModels;Initial Catalog=Demo1DB;TrustServerCertificate=True;Integrated Security=SSPI;");
            base.OnConfiguring(optionsBuilder);
        }
    }
}
