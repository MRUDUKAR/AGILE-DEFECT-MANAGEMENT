﻿namespace DefectManagement_DAL
{
    public class Class1
    {

    }
}
