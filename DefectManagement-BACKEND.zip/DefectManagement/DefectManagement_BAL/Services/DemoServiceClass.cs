﻿using AutoMapper;
using DefectManagement_DAL.Models;
using DefectManagement1_BAL.DemoDTO;
using DefectManagement1_BAL.MaximumDemoDefectException;
using DefectManagement1_DAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DefectManagement1_BAL.Services
{
    public class DemoServiceClass : IDemoServiceClass
    {

        private readonly IDemoRepository _demoRepository;
        private readonly IMapper _mapper;

        public DemoServiceClass(IDemoRepository demoRepository, IMapper mapper)
        {
            _demoRepository = demoRepository;
            _mapper = mapper;
        }

        DateOnly expectedDemoResolution;


        public bool AddNewDemoDefect(DemoDefectDTO demoDefectDTO)
        {
            try
            {
                ValidateDemodefect(demoDefectDTO);

                DateOnly detectedon1 = DateOnly.FromDateTime(DateTime.Today);

                Defect1 defect1 = new Defect1()
                {
                    Title1 = demoDefectDTO.Title1,
                    DefectDetails1 = demoDefectDTO.DefectDetails1,
                    StepsToReproduce1 = demoDefectDTO.StepsToReproduce1,
                    Priority1 = demoDefectDTO.Priority1,
                    DefectedOn1 = DateOnly.FromDateTime(DateTime.Today),
                    ReportedByTesterId1 = demoDefectDTO.ReportedByTesterId1,
                    AssignedToDeveloperId1 = demoDefectDTO.AssignedToDeveloperId1,
                    Severity1 = demoDefectDTO.Severity1,
                    Status1 = "Pending",
                    ProjectCode1 = demoDefectDTO.ProjectCode1,


                };
                defect1.ExpectedResolution1 = CalculateExpectedDemoResolution(defect1);
                var result = _demoRepository.AddNewDemoDefect(defect1);
                return result;

            }
            catch (Exception ex)
            {
                throw;
            }
            
        }

        public IList<DemoDefectDTOs>? GetDemoDefectAssignToDeveloper(string developerid)
        {
            List<Defect1> defect = (List<Defect1>)_demoRepository.GetDemoDefectAssignToDeveloper(developerid);
            List<DemoDefectDTOs> result = new List<DemoDefectDTOs>();

            foreach(Defect1 def in defect)
            {
                DemoDefectDTOs value = _mapper.Map<DemoDefectDTOs>(def);
                result.Add(value);
            }
            return result;
         }

        public DemoDefectDetailsDTO GetDemoDefectById(int defectid)
        {
            try
            {
                var defectdetails = _demoRepository.GetDemoDefectById(defectid);
                if (defectdetails == null)
                {
                    return null;
                }
                else
                {
                    DemoDefectDetailsDTO demoDefectDetailsDTO = new DemoDefectDetailsDTO()
                    {
                        DefectId1 = defectdetails.DefectId1,
                        Title1 = defectdetails.Title1,
                        DefectDetails1 = defectdetails.DefectDetails1,
                        StepsToReproduce1 = defectdetails.StepsToReproduce1,
                        Priority1 = defectdetails.Priority1,
                        DefectedOn1 = defectdetails.DefectedOn1,
                        ExpectedResolution1 = defectdetails.ExpectedResolution1,
                        ReportedByTesterId1 = defectdetails.ReportedByTesterId1,
                        AssignedToDeveloperId1 = defectdetails.AssignedToDeveloperId1,
                        Severity1 = defectdetails.Severity1,
                        Status1 = defectdetails.Status1,
                        ProjectCode1 = defectdetails.ProjectCode1,

                    };
                    return demoDefectDetailsDTO;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool UpdateDemoDefectWithResolution(DemoUpdateDefectDTO updateDefectDTO, int id)
        {
            try
            {
                Defect1 defect1 = new Defect1()
                {
                    DefectId1 = id,
                    Status1 = "Resolved"
                };
                var result = _demoRepository.UpdateDemoDefect(defect1, id);
                return result;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public IList<DemoDefectReportDTO>? GetDemoDefectReport(int projectcode)
        {
            List<Defect1> defect1s = (List<Defect1>)_demoRepository.GetDemoDefectReport(projectcode);
            List<DemoDefectReportDTO> result = new List<DemoDefectReportDTO>();

            foreach (Defect1 def in defect1s)
            {
                DemoDefectReportDTO value = _mapper.Map<DemoDefectReportDTO>(def);
                result.Add(value);
            }
            return result;
        }

        public DateOnly CalculateExpectedDemoResolution(Defect1 defect)
        {
            if (defect.Severity1 == Defect1.Severity1_value.blocker)
            {
                if(defect.Priority1 == Defect1.Priority1_value.P1)
                {
                    expectedDemoResolution = defect.DefectedOn1.AddDays(2);
                }
                else if(defect.Priority1 == Defect1.Priority1_value.P2)
                {
                    expectedDemoResolution = defect.DefectedOn1.AddDays(3);
                }
                else
                {
                    expectedDemoResolution = defect.DefectedOn1.AddDays(5);
                }
            }
            else if (defect.Severity1 == Defect1.Severity1_value.critical)
            {
                if (defect.Priority1 == Defect1.Priority1_value.P1)
                {
                    expectedDemoResolution = defect.DefectedOn1.AddDays(1);
                }
                else if (defect.Priority1 == Defect1.Priority1_value.P2)
                {
                    expectedDemoResolution = defect.DefectedOn1.AddDays(2);
                }
                else
                {
                    expectedDemoResolution = defect.DefectedOn1.AddDays(8);
                }

            }
            else
            {
                switch(defect.Priority1)
                {
                    case Defect1.Priority1_value.P1:
                        expectedDemoResolution = defect.DefectedOn1.AddDays(5);
                        break;
                    case Defect1.Priority1_value.P2:
                        expectedDemoResolution = defect.DefectedOn1.AddDays(8);
                        break;
                    case Defect1.Priority1_value.P3:
                        expectedDemoResolution = defect.DefectedOn1.AddDays(10);
                        break;
                }
            }
            return expectedDemoResolution;
        }

        public void ValidateDemodefect(DemoDefectDTO defect)
        {
            if(string.IsNullOrWhiteSpace(defect.StepsToReproduce1) || defect.StepsToReproduce1.Split(' ').Length < 10)
            {
                throw new ArgumentException("Steps to reproduce must be atleast 10 words.");
            }

            if(string.IsNullOrWhiteSpace(defect.DefectDetails1) || defect.DefectDetails1.Split(' ').Length < 10)
            {
                throw new ArgumentException("Defect details must be atleast 10 words");
            }
            
        }

    }
}
