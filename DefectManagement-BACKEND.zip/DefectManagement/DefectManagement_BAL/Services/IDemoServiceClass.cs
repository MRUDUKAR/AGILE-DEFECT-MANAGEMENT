﻿using DefectManagement1_BAL.DemoDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefectManagement1_BAL.Services
{
    public interface IDemoServiceClass
    {
        public bool AddNewDemoDefect(DemoDefectDTO demoDefectDTO);

        public IList<DemoDefectDTOs>? GetDemoDefectAssignToDeveloper(string developerid);

        public DemoDefectDetailsDTO? GetDemoDefectById(int defectid);

        public bool UpdateDemoDefectWithResolution(DemoUpdateDefectDTO updateDefectDTO, int id);

        public IList<DemoDefectReportDTO>? GetDemoDefectReport(int projectcode);
    }
}
