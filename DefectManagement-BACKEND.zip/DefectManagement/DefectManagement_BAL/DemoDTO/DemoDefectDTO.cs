﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static DefectManagement_DAL.Models.Defect1;

namespace DefectManagement1_BAL.DemoDTO
{
    public class DemoDefectDTO
    {

        public string Title1 { get; set; }

        public string DefectDetails1 { get; set; }

        public string? StepsToReproduce1 { get; set; }

        public Priority1_value Priority1 { get; set; }

        public string ReportedByTesterId1 { get; set; }

        public string AssignedToDeveloperId1 { get; set; }

        public Severity1_value Severity1 { get; set; }

        public string Status1 { get; set; }

        public int ProjectCode1 { get; set; }
    }
}
