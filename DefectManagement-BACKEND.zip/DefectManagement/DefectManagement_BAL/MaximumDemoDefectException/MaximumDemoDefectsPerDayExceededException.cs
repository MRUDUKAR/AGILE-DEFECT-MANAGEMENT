﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DefectManagement1_BAL.MaximumDemoDefectException
{
        [Serializable]
        internal class MaximumDefectsPerDayExceededException : Exception
        {
            public MaximumDefectsPerDayExceededException()
            {
            }

            public MaximumDefectsPerDayExceededException(string? message) : base(message)
            {
            }

            public MaximumDefectsPerDayExceededException(string? message, Exception? innerException) : base(message, innerException)
            {
            }

            protected MaximumDefectsPerDayExceededException(SerializationInfo info, StreamingContext context) : base(info, context)
            {
            }
        }
    }

