﻿using AutoMapper;
using DefectManagement_DAL.Models;
using DefectManagement1_BAL.DemoDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DefectManagement1_BAL.Services;

namespace DefectManagement1_BAL.Mappers
{
    public class DemoAuto_Mapper : Profile
    {
        public DemoAuto_Mapper() {

            CreateMap<Defect1, DemoDefectDTOs>()
                .ForMember(cd => cd.DefectId1, opt => opt.MapFrom(cld => cld.DefectId1))
                .ForMember(cd => cd.Title1, opt => opt.MapFrom(cld => cld.Title1))
                .ForMember(cd => cd.DefectDetails1, opt => opt.MapFrom(cld => cld.DefectDetails1))
                .ForMember(cd => cd.StepsToReproduce1, opt => opt.MapFrom(cld => cld.StepsToReproduce1))
                .ForMember(cd => cd.Priority1, opt => opt.MapFrom(cld => cld.Priority1))
                .ForMember(cd => cd.DefectedOn1, opt => opt.MapFrom(cld => cld.DefectedOn1))
                .ForMember(cd => cd.ExpectedResolution1, opt => opt.MapFrom(cld => cld.ExpectedResolution1))
                .ForMember(cd => cd.ReportedByTesterId1, opt => opt.MapFrom(cld => cld.ReportedByTesterId1))
                .ForMember(cd => cd.AssignedToDeveloperId1, opt => opt.MapFrom(cld => cld.AssignedToDeveloperId1))
                .ForMember(cd => cd.Severity1, opt => opt.MapFrom(cld => cld.Severity1))
                .ForMember(cd => cd.Status1, opt => opt.MapFrom(cld => cld.Status1))
                .ForMember(cd => cd.ProjectCode1, opt => opt.MapFrom(cld => cld.ProjectCode1));

            CreateMap<Defect1, DemoDefectReportDTO>()
                .ForMember(cd => cd.DefectId1, opt => opt.MapFrom(cld => cld.DefectId1))
                .ForMember(cd => cd.Title1, opt => opt.MapFrom(cld => cld.Title1))
                .ForMember(cd => cd.DefectDetails1, opt => opt.MapFrom(cld => cld.DefectDetails1))
                .ForMember(cd => cd.StepsToReproduce1, opt => opt.MapFrom(cld => cld.StepsToReproduce1))
                .ForMember(cd => cd.Priority1, opt => opt.MapFrom(cld => cld.Priority1))
                .ForMember(cd => cd.DefectedOn1, opt => opt.MapFrom(cld => cld.DefectedOn1))
                .ForMember(cd => cd.ExpectedResolution1, opt => opt.MapFrom(cld => cld.ExpectedResolution1))
                .ForMember(cd => cd.ReportedByTesterId1, opt => opt.MapFrom(cld => cld.ReportedByTesterId1))
                .ForMember(cd => cd.AssignedToDeveloperId1, opt => opt.MapFrom(cld => cld.AssignedToDeveloperId1))
                .ForMember(cd => cd.Severity1, opt => opt.MapFrom(cld => cld.Severity1))
                .ForMember(cd => cd.Status1, opt => opt.MapFrom(cld => cld.Status1))
                .ForMember(cd => cd.ProjectCode1, opt => opt.MapFrom(cld => cld.ProjectCode1));




        }

    }
}
